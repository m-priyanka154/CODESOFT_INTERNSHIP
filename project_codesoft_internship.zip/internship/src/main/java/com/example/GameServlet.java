package com.example;

import java.io.IOException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

	public class GameServlet extends HttpServlet {
	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        
	        HttpSession session = request.getSession();
	        Integer target = (Integer) session.getAttribute("target");
	        Integer attempts = (Integer) session.getAttribute("attempts");
	        Integer score = (Integer) session.getAttribute("score");

	        if (target == null || attempts == null || score == null) {
	            target = new Random().nextInt(100) + 1;
	            attempts = 5;
	            score = 0;
	            session.setAttribute("target", target);
	            session.setAttribute("attempts", attempts);
	            session.setAttribute("score", score);
	        }

	        int guess = Integer.parseInt(request.getParameter("guess"));

	        if (guess == target) {
	            session.setAttribute("message", "🎉 Correct! The number was " + target + ". Starting a new round.");
	            score += 10;
	            target = new Random().nextInt(100) + 1;
	            attempts = 5;
	        } else {
	            attempts--;
	            if (attempts <= 0) {
	                session.setAttribute("message", "❌ Out of attempts! The number was " + target + ". Starting a new round.");
	                target = new Random().nextInt(100) + 1;
	                attempts = 5;
	            } else {
	                String hint = guess < target ? "Too low!" : "Too high!";
	                session.setAttribute("message", hint);
	            }
	        }

	        session.setAttribute("target", target);
	        session.setAttribute("attempts", attempts);
	        session.setAttribute("score", score);

	        response.sendRedirect("index.jsp");
	    }
	}



