package com.atm;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;

public class ATMServlet extends HttpServlet {
    private BankAccount account = new BankAccount();

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        String message = "";
        double balance = account.getBalance();

        switch (action) {
            case "deposit":
                double depositAmt = Double.parseDouble(request.getParameter("amount"));
                if (account.deposit(depositAmt)) {
                    message = "₹" + depositAmt + " deposited successfully.";
                } else {
                    message = "Invalid deposit amount!";
                }
                break;

            case "withdraw":
                double withdrawAmt = Double.parseDouble(request.getParameter("amount"));
                if (account.withdraw(withdrawAmt)) {
                    message = "₹" + withdrawAmt + " withdrawn successfully.";
                } else {
                    message = "Insufficient balance or invalid amount!";
                }
                break;

            case "check":
                message = "Your current balance is ₹" + balance;
                break;
        }

        request.setAttribute("message", message);
        request.setAttribute("balance", account.getBalance());
        RequestDispatcher rd = request.getRequestDispatcher("atm.jsp");
        rd.forward(request, response);
    }
}
