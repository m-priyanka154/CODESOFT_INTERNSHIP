package com.marks;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;

public class GradeServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int s1 = Integer.parseInt(request.getParameter("subject1"));
        int s2 = Integer.parseInt(request.getParameter("subject2"));
        int s3 = Integer.parseInt(request.getParameter("subject3"));
        int s4 = Integer.parseInt(request.getParameter("subject4"));
        int s5 = Integer.parseInt(request.getParameter("subject5"));

        int total = s1 + s2 + s3 + s4 + s5;
        double avg = total / 5.0;
        String grade;

        if (avg >= 90) grade = "A+";
        else if (avg >= 80) grade = "A";
        else if (avg >= 70) grade = "B";
        else if (avg >= 60) grade = "C";
        else if (avg >= 50) grade = "D";
        else grade = "F";

        request.setAttribute("total", total);
        request.setAttribute("average", avg);
        request.setAttribute("grade", grade);

        RequestDispatcher rd = request.getRequestDispatcher("result.jsp");
        rd.forward(request, response);
    }
}
